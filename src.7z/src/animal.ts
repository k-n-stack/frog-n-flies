class animal {
  
}
