class grenouille extends animal {

  constructor () {
    super();
  }

  move (commande:String) {
    
  }

}
