import {Circuit} from "./circuit.js"

var test : Circuit = new Circuit(10, 10, 0);
test.generate(20);